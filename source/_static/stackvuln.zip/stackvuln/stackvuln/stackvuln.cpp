// stackvuln.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include"stdafx.h"
#include<Windows.h>

#define PASSWORFD "1234567"

int verify_password(char *password)
{
	int authenticated;
	char buffer[44];
	authenticated = strcmp(PASSWORFD, password);
	strcpy(buffer, password);
	return authenticated;
}


int main(int argc, char* argv[])
{
	
	if (argc > 1)
	{
		int valid_flag = 0;
		char password[1024];
		FILE *fp;
		LoadLibrary("user32.dll");
		if (!(fp = fopen(argv[1], "r")))
		{
			printf("password.txt open failed");
			exit(0);
		}
		fscanf(fp, "%s", password);
		valid_flag = verify_password(password);
		if (valid_flag)
			printf("incorrect password!\n");
		else
		{
			printf("Congratulation!You have passed the verification!");
		}
		fclose(fp);
	}
	else
		printf("main argu error!");
    return 0;
}

