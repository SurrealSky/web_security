import socket

if __name__ == '__main__':
	aim = ("192.168.99.54", 48898)
	tcpSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	tcpSocket.settimeout(1)
	

try:
	tcpSocket.connect(aim)
except:
	tcpSocket.close()
	print("failed")
	exit(-1)
else:
	tcpSocket.close()
	print("success")
	exit(0)
