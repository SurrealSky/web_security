// HeapBase.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <windows.h>

int main()
{
	HLOCAL h1, h2, h3, h4, h5, h6;
	HANDLE hp;
	hp = HeapCreate(0, 0x1000, 0x10000);
	
	h1 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h1, 0x11, 8);
	h2 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h2, 0x22, 8);
	h3 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h3, 0x33, 8);
	h4 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h4, 0x44, 8);
	h5 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h5, 0x55, 8);
	h6 = HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);
	memset(h6, 0x66, 8);
	getchar();

	//free block and prevent coaleses
	HeapFree(hp, 0, h1); //free to freelist[2] 
	HeapFree(hp, 0, h3); //free to freelist[2] 
	HeapFree(hp, 0, h5); //free to freelist[4]

	h1= HeapAlloc(hp, HEAP_ZERO_MEMORY, 8);


	return 0;
}

